
AddRoom("BeefalowPlain", {
					colour={r=.45,g=.5,b=.85,a=.50},
					value = GROUND.SAVANNA,
					contents =  {
					                distributepercent = .05,
					                distributeprefabs= {
					                    grass = .01,
					                    beefalo = 0.02,
					                } 
					            }
					})

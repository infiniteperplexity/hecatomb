
require "translator"

require "fonts_default"

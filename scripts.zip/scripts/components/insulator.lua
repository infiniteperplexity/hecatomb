local Insulator = Class(function(self, inst)
    self.inst = inst
    self.insulation = 0
end)

return Insulator

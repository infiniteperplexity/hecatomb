local player = GetPlayer()

if player.components.playercontroller.autoequip_OriginalOnUpdate == nil then
	player.components.playercontroller.autoequip_OriginalOnUpdate = player.components.playercontroller.OnUpdate
else
	print("autoequip_OriginalOnUpdate already set")
end

if player.components.playercontroller.autoequip_OriginalGetActionButtonAction == nil then
	player.components.playercontroller.autoequip_OriginalGetActionButtonAction = player.components.playercontroller.GetActionButtonAction
else
	print("autoequip_OriginalGetActionButtonAction already set")
end

if player.components.playercontroller.autoequip_OriginalDoAction == nil then
	player.components.playercontroller.autoequip_OriginalDoAction = player.components.playercontroller.DoAction
else
	print("autoequip_OriginalDoAction already set")
end

if player.components.playercontroller.autoequip_OriginalDoAttackButton == nil then
	player.components.playercontroller.autoequip_OriginalDoAttackButton = player.components.playercontroller.DoAttackButton
else
	print("autoequip_OriginalDoAttackButton already set")
end

if player.components.playeractionpicker.autoequip_OriginalGetClickActions == nil then
	player.components.playeractionpicker.autoequip_OriginalGetClickActions = player.components.playeractionpicker.GetClickActions
else
	print("autoequip_OriginalGetClickActions already set")
end

if player.components.playeractionpicker.autoequip_OriginalGetRightClickActions == nil then
	player.components.playeractionpicker.autoequip_OriginalGetRightClickActions = player.components.playeractionpicker.GetRightClickActions
else
	print("autoequip_OriginalGetRightClickActions already set")
end

local function FindTool(inventory, action)
	return inventory:FindItem(function(item)
			return item.components.tool and item.components.tool:CanDoAction(action)
		end)
end

local function FindWorkableEntity(inst, action, radius)
	return FindEntity(inst, radius, function(entitiy) 
			return (action ~= ACTIONS.NET or (entitiy.components.health and not entitiy.components.health:IsDead()))
				and (action ~= ACTIONS.DIG or (entitiy.prefab ~= "berrybush" and entitiy.prefab ~= "berrybush2" and entitiy.prefab ~= "grass" and entitiy.prefab ~= "rabbithole" and entitiy.prefab ~= "sapling"))
				and entitiy.components.workable
				and	entitiy.components.workable.action == action
		end)
end

local function GetAction(inst, target, action)
	local tool = FindTool(inst.components.inventory, action)
	if not tool then return end
	if action == ACTIONS.NET and (not target.components.health or target.components.health:IsDead()) then return end
	if not target.components.workable then return end
	if target.components.workable.action ~= action then return end
	local action = BufferedAction(inst, target, action, tool)
	action.autoequip = true
	return action
end

local function GetBestWeapon(inst)
	local bestweapon = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	-- do not replace a ranged weapon
	if bestweapon and bestweapon.components.weapon and bestweapon.components.weapon.attackrange ~= nil then return bestweapon end
	local weapons = inst.components.inventory:FindItems(function(item)
			return item.components.weapon
		end)
	if weapons then
		for k,v in pairs(weapons) do
			--[[
			local damage = v.components.weapon.damage
			if v.components.weapon.variedmodefn then
				local d = v.components.weapon.variedmodefn(v)
				weapondamage = d.damage
			end
			print("weapon "..v.prefab..": damage = "..damage)
			]]
		    -- only select melee weapons
			if v.components.weapon.attackrange == nil then
				if not bestweapon or (v.components.weapon.damage > bestweapon.components.weapon.damage) then
					-- print("switching to "..v.prefab)
					bestweapon = v
				end
			end
		end
	end
	return bestweapon
end

local function AutoEquipItem(playercontroller, bufferedaction)
	if not bufferedaction then return end
	if not bufferedaction.invobject then return end
	if not playercontroller.autoequip_lastequipped then
		playercontroller.autoequip_lastequipped = playercontroller.inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	end
	playercontroller.inst.components.locomotor:PushAction(BufferedAction(playercontroller.inst, nil, ACTIONS.EQUIP, bufferedaction.invobject), true)
    -- playercontroller.inst.components.inventory:Equip(bufferedaction.invobject)
end

local function AutoEquipBestWeapon(playercontroller, bufferedaction)
	local bestweapon = GetBestWeapon(playercontroller.inst)
	if not bestweapon or bestweapon == playercontroller.inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) then return end
	bufferedaction.invobject = bestweapon
	AutoEquipItem(playercontroller, bufferedaction)
end

-- attached to playercontroller.OnUpdate
local function OnUpdate(playercontroller, dt)
	if not playercontroller:IsEnabled() then return end
	if not playercontroller.autoequip_lastequipped then return end
	if not playercontroller.inst.sg:HasStateTag("idle") then return end
	if TheInput:IsControlPressed(CONTROL_PRIMARY) then return end
	if TheInput:IsControlPressed(CONTROL_SECONDARY) then return end
	if TheInput:IsControlPressed(CONTROL_ACTION) then return end
	if TheInput:IsControlPressed(CONTROL_ATTACK) then return end
	if playercontroller.inst.sg:HasStateTag("working") then return end
	if playercontroller.inst.sg:HasStateTag("doing") then return end
	if playercontroller.inst.sg:HasStateTag("attack") then return end
	if playercontroller.inst.components.combat.target ~= nil then return end
	-- print("switch to previous equipped item")
	playercontroller.inst.components.locomotor:PushAction(BufferedAction(playercontroller.inst, nil, ACTIONS.EQUIP, playercontroller.autoequip_lastequipped), true)
	-- playercontroller.inst.components.inventory:Equip(playercontroller.autoequip_lastequipped)
	playercontroller.autoequip_lastequipped = nil
	
end

-- attached to playercontroller.GetActionButtonAction
local function GetActionButtonAction(playercontroller, bufferedaction)
	if bufferedaction then return bufferedaction end
	if not playercontroller:IsEnabled() then return end
	if playercontroller.inst.sg:HasStateTag("working") or playercontroller.inst.sg:HasStateTag("doing") then return end
	local tool
	local target
	tool = FindTool(playercontroller.inst.components.inventory, ACTIONS.NET)
	target = FindWorkableEntity(playercontroller.inst, ACTIONS.NET, 5)
	if not (tool and target) then
		tool = FindTool(playercontroller.inst.components.inventory, ACTIONS.CHOP)
		target = FindWorkableEntity(playercontroller.inst, ACTIONS.CHOP, playercontroller.directwalking and 3 or 6)
	end
	if not (tool and target) then
		tool = FindTool(playercontroller.inst.components.inventory, ACTIONS.MINE)
		target = FindWorkableEntity(playercontroller.inst, ACTIONS.MINE, playercontroller.directwalking and 3 or 6)
	end
	if not (tool and target) then
		tool = FindTool(playercontroller.inst.components.inventory, ACTIONS.DIG)
		target = FindWorkableEntity(playercontroller.inst, ACTIONS.DIG, playercontroller.directwalking and 3 or 6)
	end
	if tool and target then
		if not playercontroller.autoequip_lastequipped then
			playercontroller.autoequip_lastequipped = playercontroller.inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		end
		playercontroller.inst.components.locomotor:PushAction(BufferedAction(playercontroller.inst, nil, ACTIONS.EQUIP, tool), true)
		playercontroller.inst.components.locomotor:PushAction(BufferedAction(playercontroller.inst, target, target.components.workable.action, tool), true)
	else
		if playercontroller.autoequip_lastequipped then
			playercontroller.inst.components.locomotor:PushAction(BufferedAction(playercontroller.inst, nil, ACTIONS.EQUIP, playercontroller.autoequip_lastequipped), true)
			playercontroller.autoequip_lastequipped = nil
		end
	end
end

-- attached to playercontroller.DoAction
local function DoAction(playercontroller, bufferedaction)
	if not bufferedaction then return end
	if not bufferedaction.action then return end
	if bufferedaction.action == ACTIONS.ATTACK then
		AutoEquipBestWeapon(playercontroller, bufferedaction)
		return
	end
	
	if not bufferedaction.autoequip then return end
	if not bufferedaction.invobject then return end
    if not bufferedaction.invobject.components.equippable then return end
	if bufferedaction.invobject.components.equippable.isequipped then return end
	AutoEquipItem(playercontroller, bufferedaction)
end

-- attached to playercontroller.DoAttackButton
local function DoAttackButton(playercontroller)
	local target = playercontroller:GetAttackTarget(TheInput:IsControlPressed(CONTROL_FORCE_ATTACK)) 			
	if target and playercontroller.inst.components.combat.target ~= target then
		local bufferedaction = BufferedAction(playercontroller.inst, target, ACTIONS.ATTACK)
		AutoEquipBestWeapon(playercontroller, bufferedaction)
		playercontroller.inst.components.locomotor:PushAction(bufferedaction, true)
	end
end

-- attached to playercontroller.GetClickActions
local function GetClickActions(playeractionpicker, target, position, actions)
	if not target then return actions end
	if not actions then return actions end
	local action
	for k,v in ipairs(actions) do
		if v.action == ACTIONS.ATTACK then
			action = GetAction(playeractionpicker.inst, target, ACTIONS.NET)
		end
		if not action and v.action == ACTIONS.ATTACK then
			action = GetAction(playeractionpicker.inst, target, ACTIONS.NET)
		end
		if not action and (v.action == ACTIONS.LOOKAT or ACTIONS.WALKTO) then
			action = GetAction(playeractionpicker.inst, target, ACTIONS.CHOP)
		end
		if not action and (v.action == ACTIONS.LOOKAT or ACTIONS.WALKTO) then
			action = GetAction(playeractionpicker.inst, target, ACTIONS.MINE)
		end
		if action then
			actions[k] = action
			action = nil
		end
	end
	return actions
end

-- attached to playercontroller.GetRightClickActions
local function GetRightClickActions(playeractionpicker, target, position, actions)
	if not target then return actions end
	if not actions then return actions end
	local action
	for k,v in ipairs(actions) do
		if v.action == ACTIONS.LOOKAT or v.action == ACTIONS.WALKTO or v.action == ACTIONS.PICK then
			action = GetAction(playeractionpicker.inst, target, ACTIONS.DIG)
		end
		if not action then
			action = GetAction(playeractionpicker.inst, target, ACTIONS.HAMMER)
		end
		if action then
			actions[k] = action
			action = nil
		end
	end
	return actions
end

-- overwrite playercontroller.OnUpdate
player.components.playercontroller.OnUpdate = function(self, dt)
		self:autoequip_OriginalOnUpdate(dt)
		local successflag, retvalue = pcall(OnUpdate, self, dt)
		if not successflag then
			print(retvalue)
		end
	end

-- overwrite playercontroller.GetActionButtonAction
player.components.playercontroller.GetActionButtonAction = function(self)
		local bufferedaction = self:autoequip_OriginalGetActionButtonAction()
		local successflag, retvalue = pcall(GetActionButtonAction, self, bufferedaction)
		if not successflag then
			print(retvalue)
			return bufferedaction
		else
			return retvalue
		end
	end

-- overwrite playercontroller.DoAction
player.components.playercontroller.DoAction = function(self, bufferedaction)
		local successflag, retvalue = pcall(DoAction, self, bufferedaction)
		if not successflag then
			print(retvalue)
		end
		self:autoequip_OriginalDoAction(bufferedaction)
	end
	
-- overwrite playercontroller.DoAttackButton
player.components.playercontroller.DoAttackButton = function(self)
		local successflag, retvalue = pcall(DoAttackButton, self)
		if not successflag then
			print(retvalue)
		end
		self:autoequip_OriginalDoAttackButton()
	end
	
-- overwrite playercontroller.GetClickActions
player.components.playeractionpicker.GetClickActions = function(self, target, position)
		local actions =  self:autoequip_OriginalGetClickActions(target, position)
		local successflag, retvalue = pcall(GetClickActions, self, target, position, actions)
		if not successflag then
			print(retvalue)
			return actions
		else
			return retvalue
		end
	end
	
-- overwrite playercontroller.GetRightClickActions
player.components.playeractionpicker.GetRightClickActions = function(self, target, position)
		local actions =  self:autoequip_OriginalGetRightClickActions(target, position)
		local successflag, retvalue = pcall(GetRightClickActions, self, target, position, actions)
		if not successflag then
			print(retvalue)
			return actions
		else
			return retvalue
		end
	end
	
print("script loaded")
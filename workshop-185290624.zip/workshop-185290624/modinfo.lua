name = "Auto Equip"
description = "Automatically equips the right tool for the job"
author = "noobler"
version = "0.4"
forumthread = "/files/file/341-auto-equip/"
api_version = 4
icon_atlas = "modicon.xml"
icon = "modicon.tex"
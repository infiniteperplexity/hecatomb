local function LoadScript(filename)
	local fn = GLOBAL.loadfile("scripts/"..filename..".lua")
	if not fn then return end
	local successflag, retvalue = GLOBAL.pcall(fn)
	if successflag then
		GLOBAL.GetPlayer().SoundEmitter:PlaySound("dontstarve/HUD/collect_newitem")
	else
		print(retvalue)
	end
end

local function OnSimPostInit(player)
	LoadScript("auto_equip")
	--[[
	GLOBAL.TheInput:AddKeyDownHandler(GLOBAL.KEY_Y, function()
			LoadScript("auto_equip")
		end)
	]]
end

AddSimPostInit(OnSimPostInit)